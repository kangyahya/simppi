#
# TABLE STRUCTURE FOR: bank
#

DROP TABLE IF EXISTS `bank`;

CREATE TABLE `bank` (
  `id_bank` int(11) NOT NULL AUTO_INCREMENT,
  `nama_bank` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `no_rekening` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `nama_rekening` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `alamat` text COLLATE utf8mb4_bin NOT NULL,
  `kontak` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id_bank`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `bank` (`id_bank`, `nama_bank`, `no_rekening`, `nama_rekening`, `alamat`, `kontak`) VALUES (1, 'BRI', '312910', 'Ahmad Hanafi', 'Cirebon, Jawa Barat', '120210');
INSERT INTO `bank` (`id_bank`, `nama_bank`, `no_rekening`, `nama_rekening`, `alamat`, `kontak`) VALUES (2, 'BCA', '12931021', 'Alhanif', 'Bandung, Jawa Barat', '0849189');
INSERT INTO `bank` (`id_bank`, `nama_bank`, `no_rekening`, `nama_rekening`, `alamat`, `kontak`) VALUES (3, ' BNI', '8198031-2181', 'Hanif', 'Kuningan, Jabar ', '02197189');


#
# TABLE STRUCTURE FOR: biaya
#

DROP TABLE IF EXISTS `biaya`;

CREATE TABLE `biaya` (
  `id_biaya` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `keterangan` text COLLATE utf8mb4_bin,
  `jenis_biaya` enum('MASUK','KELUAR') COLLATE utf8mb4_bin NOT NULL,
  `nominal` double NOT NULL,
  `saldo` double NOT NULL,
  `foto` varchar(200) COLLATE utf8mb4_bin DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_biaya`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `biaya` (`id_biaya`, `tanggal`, `keterangan`, `jenis_biaya`, `nominal`, `saldo`, `foto`, `status`) VALUES (2, '2020-10-07', 'Saldo awal\r\n', 'MASUK', '50000000', '50000000', '20_10_06_11-08-48pm.png', 1);
INSERT INTO `biaya` (`id_biaya`, `tanggal`, `keterangan`, `jenis_biaya`, `nominal`, `saldo`, `foto`, `status`) VALUES (3, '2020-10-07', 'Transferan dari Bapak Yudi', 'MASUK', '10000000', '60000000', '20_10_06_11-09-30pm.png', 1);
INSERT INTO `biaya` (`id_biaya`, `tanggal`, `keterangan`, `jenis_biaya`, `nominal`, `saldo`, `foto`, `status`) VALUES (4, '2020-10-08', 'Beli Bahan Baku', 'KELUAR', '5000000', '55000000', '20_10_06_11-13-50pm.png', 1);


#
# TABLE STRUCTURE FOR: detail_pembayaran_hutang
#

DROP TABLE IF EXISTS `detail_pembayaran_hutang`;

CREATE TABLE `detail_pembayaran_hutang` (
  `id_detail_pembayaran_hutang` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembayaran_hutang` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `no_nota` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `nominal_bayar` double NOT NULL,
  `no_retur` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `potongan_retur` double DEFAULT NULL,
  PRIMARY KEY (`id_detail_pembayaran_hutang`),
  KEY `id_pembayaran_hutang` (`id_pembayaran_hutang`),
  KEY `no_nota` (`no_nota`),
  KEY `no_retur` (`no_retur`),
  CONSTRAINT `detail_pembayaran_hutang_ibfk_1` FOREIGN KEY (`id_pembayaran_hutang`) REFERENCES `pembayaran_hutang` (`id_pembayaran_hutang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_pembayaran_hutang_ibfk_2` FOREIGN KEY (`no_nota`) REFERENCES `nota_pembelian` (`no_nota`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_pembayaran_hutang_ibfk_3` FOREIGN KEY (`no_retur`) REFERENCES `retur_supplier` (`no_retur`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `detail_pembayaran_hutang` (`id_detail_pembayaran_hutang`, `id_pembayaran_hutang`, `tanggal`, `no_nota`, `nominal_bayar`, `no_retur`, `potongan_retur`) VALUES (1, 1, '2020-10-04', '01', '500000', NULL, '0');
INSERT INTO `detail_pembayaran_hutang` (`id_detail_pembayaran_hutang`, `id_pembayaran_hutang`, `tanggal`, `no_nota`, `nominal_bayar`, `no_retur`, `potongan_retur`) VALUES (2, 1, '2020-10-04', '01', '500000', NULL, '0');


#
# TABLE STRUCTURE FOR: detail_pembayaran_piutang
#

DROP TABLE IF EXISTS `detail_pembayaran_piutang`;

CREATE TABLE `detail_pembayaran_piutang` (
  `id_detail_pembayaran_piutang` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembayaran_piutang` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `no_nota` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `nominal_bayar` double NOT NULL,
  `no_retur` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `potongan_retur` double DEFAULT NULL,
  PRIMARY KEY (`id_detail_pembayaran_piutang`),
  KEY `id_pembayaran_piutang` (`id_pembayaran_piutang`),
  KEY `no_nota` (`no_nota`),
  KEY `no_retur` (`no_retur`),
  CONSTRAINT `detail_pembayaran_piutang_ibfk_1` FOREIGN KEY (`id_pembayaran_piutang`) REFERENCES `pembayaran_piutang` (`id_pembayaran_piutang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_pembayaran_piutang_ibfk_2` FOREIGN KEY (`no_nota`) REFERENCES `nota_penjualan` (`no_nota`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_pembayaran_piutang_ibfk_3` FOREIGN KEY (`no_retur`) REFERENCES `retur_penjualan` (`no_retur`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `detail_pembayaran_piutang` (`id_detail_pembayaran_piutang`, `id_pembayaran_piutang`, `tanggal`, `no_nota`, `nominal_bayar`, `no_retur`, `potongan_retur`) VALUES (1, 1, '2020-09-07', '01', '5000000', 'RET-01', '25000');
INSERT INTO `detail_pembayaran_piutang` (`id_detail_pembayaran_piutang`, `id_pembayaran_piutang`, `tanggal`, `no_nota`, `nominal_bayar`, `no_retur`, `potongan_retur`) VALUES (2, 1, '2020-10-06', '02', '2500000', NULL, '0');
INSERT INTO `detail_pembayaran_piutang` (`id_detail_pembayaran_piutang`, `id_pembayaran_piutang`, `tanggal`, `no_nota`, `nominal_bayar`, `no_retur`, `potongan_retur`) VALUES (4, 3, '2020-10-06', '02', '20000000', NULL, '0');


#
# TABLE STRUCTURE FOR: jenis_bayar
#

DROP TABLE IF EXISTS `jenis_bayar`;

CREATE TABLE `jenis_bayar` (
  `id_jenis_bayar` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jenis_bayar` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `keterangan` text COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id_jenis_bayar`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `jenis_bayar` (`id_jenis_bayar`, `nama_jenis_bayar`, `keterangan`) VALUES (1, 'TRANSFER', 'Transfer uang ke rekening bank milik perusahaan.');
INSERT INTO `jenis_bayar` (`id_jenis_bayar`, `nama_jenis_bayar`, `keterangan`) VALUES (2, 'GIRO', 'Giro merupakan surat perintah yang dikeluarkan oleh nasabah kepada lembaga keuangan tempatnya menabung. Surat perintah ini dikeluarkan agar melakukan proses pemindahbukuan sejumlah dana dari rekeningnya ke rekening lain yang disebutkan di dalam bilyet giro tersebut. ');
INSERT INTO `jenis_bayar` (`id_jenis_bayar`, `nama_jenis_bayar`, `keterangan`) VALUES (3, 'CEK', 'Cek adalah sebuah media penarikan tunai atau bisa dikatakan sebagai tanda terima sejumlah uang. Cek tunai merupakan cek yang tidak memiliki tanggal jatuh tempo pembayaran. Cek ini setara dengan pembayaran tunai yang bisa langsung dicairkan/diuangkan atau dipindahbukukan pada bank yang tertera di dalam cek tersebut.');
INSERT INTO `jenis_bayar` (`id_jenis_bayar`, `nama_jenis_bayar`, `keterangan`) VALUES (4, 'CASH', 'Uang tunai (cash) adalah mata uang negara dalam bentuk fisik. Uang tunai adalah uang (berupa koin atau uang kertas) yang beredar di masyarakat umum dan digunakan sebagai alat pembayaran dalam aktivitas perdagangan barang dan jasa. Penerbitan mata uang umumnya dilakukan oleh bank sentral dan Departemen Keuangan. Di negara-negara dengan perekonomian pasar yang berkembang, penghitungan uang tunai adalah sebesar 3 sampai 8?ri total semua perputaran pembayaran.');
INSERT INTO `jenis_bayar` (`id_jenis_bayar`, `nama_jenis_bayar`, `keterangan`) VALUES (6, 'BITCOIN', 'Pembayaran transaksi dengan uang digital BITCOIN');


#
# TABLE STRUCTURE FOR: keterangan
#

DROP TABLE IF EXISTS `keterangan`;

CREATE TABLE `keterangan` (
  `id_keterangan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_keterangan` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `penjelasan` text COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id_keterangan`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `keterangan` (`id_keterangan`, `nama_keterangan`, `penjelasan`) VALUES (1, 'LBH_BAYAR', 'Kelebihan bayar');
INSERT INTO `keterangan` (`id_keterangan`, `nama_keterangan`, `penjelasan`) VALUES (2, 'KRG_BAYAR', 'Kekurangan bayar');
INSERT INTO `keterangan` (`id_keterangan`, `nama_keterangan`, `penjelasan`) VALUES (3, 'PTG_EXP', 'Potongan ekspedisi');


#
# TABLE STRUCTURE FOR: nota_pembelian
#

DROP TABLE IF EXISTS `nota_pembelian`;

CREATE TABLE `nota_pembelian` (
  `id_nota_pembelian` int(11) NOT NULL AUTO_INCREMENT,
  `no_nota` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `tanggal` date NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `total` double NOT NULL,
  `total_hpp` double NOT NULL,
  `id_supplier` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_nota_pembelian`),
  UNIQUE KEY `no_nota` (`no_nota`),
  KEY `id_supplier` (`id_supplier`),
  KEY `id_pelanggan` (`id_pelanggan`),
  CONSTRAINT `nota_pembelian_ibfk_1` FOREIGN KEY (`id_supplier`) REFERENCES `supplier` (`id_supplier`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `nota_pembelian_ibfk_2` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `nota_pembelian` (`id_nota_pembelian`, `no_nota`, `tanggal`, `id_pelanggan`, `total`, `total_hpp`, `id_supplier`, `status`) VALUES (3, '01', '2020-10-04', 1, '500000', '550000', 2, 0);
INSERT INTO `nota_pembelian` (`id_nota_pembelian`, `no_nota`, `tanggal`, `id_pelanggan`, `total`, `total_hpp`, `id_supplier`, `status`) VALUES (4, '02', '2020-10-02', 2, '150000', '200000', 3, 0);


#
# TABLE STRUCTURE FOR: nota_penjualan
#

DROP TABLE IF EXISTS `nota_penjualan`;

CREATE TABLE `nota_penjualan` (
  `id_nota_penjualan` int(11) NOT NULL AUTO_INCREMENT,
  `no_nota` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `tanggal` date NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `total` double NOT NULL,
  `id_supplier` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_nota_penjualan`),
  UNIQUE KEY `no_nota` (`no_nota`),
  KEY `id_pelanggan` (`id_pelanggan`),
  KEY `id_supplier` (`id_supplier`),
  CONSTRAINT `nota_penjualan_ibfk_1` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `nota_penjualan_ibfk_2` FOREIGN KEY (`id_supplier`) REFERENCES `supplier` (`id_supplier`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `nota_penjualan` (`id_nota_penjualan`, `no_nota`, `tanggal`, `id_pelanggan`, `total`, `id_supplier`, `status`) VALUES (5, '01', '2020-09-07', 1, '5000000', 1, 0);
INSERT INTO `nota_penjualan` (`id_nota_penjualan`, `no_nota`, `tanggal`, `id_pelanggan`, `total`, `id_supplier`, `status`) VALUES (6, '02', '2020-10-06', 1, '40000000', 2, 0);
INSERT INTO `nota_penjualan` (`id_nota_penjualan`, `no_nota`, `tanggal`, `id_pelanggan`, `total`, `id_supplier`, `status`) VALUES (7, '011', '2019-10-04', 1, '3000000', 1, 0);


#
# TABLE STRUCTURE FOR: pelanggan
#

DROP TABLE IF EXISTS `pelanggan`;

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pelanggan` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `alamat` text COLLATE utf8mb4_bin NOT NULL,
  `kota` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `kontak` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id_pelanggan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `alamat`, `kota`, `kontak`) VALUES (1, 'Ahmad Hanafi', 'Jakarta, DKI Jakarta', 'Jakarta', '0891819');
INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `alamat`, `kota`, `kontak`) VALUES (2, 'Yahya', 'Cirebon, Jawa Barat', 'Cirebon', '918391891');


#
# TABLE STRUCTURE FOR: pembayaran_hutang
#

DROP TABLE IF EXISTS `pembayaran_hutang`;

CREATE TABLE `pembayaran_hutang` (
  `id_pembayaran_hutang` int(11) NOT NULL AUTO_INCREMENT,
  `kode_pembayaran` varchar(10) COLLATE utf8mb4_bin NOT NULL,
  `tanggal` date NOT NULL,
  `id_supplier` int(11) NOT NULL,
  `id_bank` int(11) NOT NULL,
  `id_jenis_bayar` int(11) NOT NULL,
  `id_keterangan` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `saldo` double NOT NULL,
  `potongan_lain_lain` double NOT NULL,
  `no_giro_cek` varchar(200) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id_pembayaran_hutang`),
  KEY `id_bank` (`id_bank`),
  KEY `id_jenis_bayar` (`id_jenis_bayar`),
  KEY `id_keterangan` (`id_keterangan`),
  KEY `id_pelanggan` (`id_supplier`),
  CONSTRAINT `pembayaran_hutang_ibfk_1` FOREIGN KEY (`id_bank`) REFERENCES `bank` (`id_bank`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pembayaran_hutang_ibfk_2` FOREIGN KEY (`id_jenis_bayar`) REFERENCES `jenis_bayar` (`id_jenis_bayar`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pembayaran_hutang_ibfk_3` FOREIGN KEY (`id_keterangan`) REFERENCES `keterangan` (`id_keterangan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pembayaran_hutang_ibfk_4` FOREIGN KEY (`id_supplier`) REFERENCES `supplier` (`id_supplier`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `pembayaran_hutang` (`id_pembayaran_hutang`, `kode_pembayaran`, `tanggal`, `id_supplier`, `id_bank`, `id_jenis_bayar`, `id_keterangan`, `jumlah`, `status`, `saldo`, `potongan_lain_lain`, `no_giro_cek`) VALUES (1, 'TF-0001', '2020-10-13', 3, 2, 2, 1, 5000000, 0, '0', '4000000', '90');


#
# TABLE STRUCTURE FOR: pembayaran_piutang
#

DROP TABLE IF EXISTS `pembayaran_piutang`;

CREATE TABLE `pembayaran_piutang` (
  `id_pembayaran_piutang` int(11) NOT NULL AUTO_INCREMENT,
  `kode_pembayaran` varchar(10) COLLATE utf8mb4_bin NOT NULL,
  `tanggal` date NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `id_bank` int(11) NOT NULL,
  `id_jenis_bayar` int(11) NOT NULL,
  `id_keterangan` int(11) NOT NULL,
  `jumlah` double NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `saldo` double NOT NULL,
  `potongan_lain_lain` double NOT NULL,
  `no_giro_cek` varchar(200) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id_pembayaran_piutang`),
  KEY `id_bank` (`id_bank`),
  KEY `id_jenis_bayar` (`id_jenis_bayar`),
  KEY `id_keterangan` (`id_keterangan`),
  KEY `id_pelanggan` (`id_pelanggan`),
  CONSTRAINT `pembayaran_piutang_ibfk_1` FOREIGN KEY (`id_bank`) REFERENCES `bank` (`id_bank`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pembayaran_piutang_ibfk_2` FOREIGN KEY (`id_jenis_bayar`) REFERENCES `jenis_bayar` (`id_jenis_bayar`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pembayaran_piutang_ibfk_3` FOREIGN KEY (`id_keterangan`) REFERENCES `keterangan` (`id_keterangan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pembayaran_piutang_ibfk_4` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `pembayaran_piutang` (`id_pembayaran_piutang`, `kode_pembayaran`, `tanggal`, `id_pelanggan`, `id_bank`, `id_jenis_bayar`, `id_keterangan`, `jumlah`, `status`, `saldo`, `potongan_lain_lain`, `no_giro_cek`) VALUES (1, 'PU-0001', '2020-10-13', 1, 1, 3, 2, '30000000', 0, '0', '0', '3901930');
INSERT INTO `pembayaran_piutang` (`id_pembayaran_piutang`, `kode_pembayaran`, `tanggal`, `id_pelanggan`, `id_bank`, `id_jenis_bayar`, `id_keterangan`, `jumlah`, `status`, `saldo`, `potongan_lain_lain`, `no_giro_cek`) VALUES (3, 'PU-0002', '2020-10-13', 2, 2, 4, 2, '20000000', 0, '0', '0', '-');


#
# TABLE STRUCTURE FOR: pengaturan_aplikasi
#

DROP TABLE IF EXISTS `pengaturan_aplikasi`;

CREATE TABLE `pengaturan_aplikasi` (
  `id_pengaturan` int(11) NOT NULL AUTO_INCREMENT,
  `show_full_sidebar` tinyint(1) NOT NULL DEFAULT '1',
  `app_name` varchar(12) COLLATE utf8mb4_bin NOT NULL,
  `color_theme` enum('DEFAULT','GREEN','BLUE','RED','ORANGE') COLLATE utf8mb4_bin NOT NULL DEFAULT 'DEFAULT',
  PRIMARY KEY (`id_pengaturan`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `pengaturan_aplikasi` (`id_pengaturan`, `show_full_sidebar`, `app_name`, `color_theme`) VALUES (1, 1, 'Codepos App', 'DEFAULT');


#
# TABLE STRUCTURE FOR: pengguna
#

DROP TABLE IF EXISTS `pengguna`;

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `username` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `level` enum('ADMIN_SUPER','ADMIN_TOKO','ADMIN_KEUANGAN','ADMIN_SUPPLIER','ADMIN_PAJAK') COLLATE utf8mb4_bin NOT NULL,
  `picture` varchar(200) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id_pengguna`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `pengguna` (`id_pengguna`, `nama_lengkap`, `username`, `email`, `password`, `level`, `picture`) VALUES (1, 'Ahmad Hanafi', 'ahanafi', 'ahanafi@mail.com', '$2y$10$tr1WCdMLl5VdmJ6zHkO2kOafK5XJSbJW1wvXaHTISOBcwg2It07I2', 'ADMIN_SUPER', NULL);
INSERT INTO `pengguna` (`id_pengguna`, `nama_lengkap`, `username`, `email`, `password`, `level`, `picture`) VALUES (2, 'Mohammad Yahya', 'yahyaa', 'yahya@gmail.com', '$2y$10$zd.WpI5471z/EsQuGOuxq.6.0mf9Rtm0zwCXU0pnctjT/hrpESIz6', 'ADMIN_SUPPLIER', NULL);
INSERT INTO `pengguna` (`id_pengguna`, `nama_lengkap`, `username`, `email`, `password`, `level`, `picture`) VALUES (4, 'Dedi Haryadi', 'dharyadi', 'dedi@mail.com', '$2y$10$UQNbH28b0AlqMK8SJ8YJ1OOqmc0MkgsNlGpnKAMjuqVSlOF5ekGOy', 'ADMIN_TOKO', NULL);
INSERT INTO `pengguna` (`id_pengguna`, `nama_lengkap`, `username`, `email`, `password`, `level`, `picture`) VALUES (6, 'Gagan', 'gagans', 'gagan@mail.com', '$2y$10$TtbsF8bTFW9sMKPFmsxPceM6beCmjwCiWUlS70N1VQfnl0FztHozu', 'ADMIN_KEUANGAN', NULL);
INSERT INTO `pengguna` (`id_pengguna`, `nama_lengkap`, `username`, `email`, `password`, `level`, `picture`) VALUES (8, 'Surya', 'suryaa', 'surya@mail.com', '$2y$10$UvFpEYcVZ/20rvxqpKlz5.we2pzqodOGuROsYsn4oVSQVLIv/v1ym', 'ADMIN_PAJAK', NULL);


#
# TABLE STRUCTURE FOR: profil_perusahaan
#

DROP TABLE IF EXISTS `profil_perusahaan`;

CREATE TABLE `profil_perusahaan` (
  `id_profil_perusahaan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_perusahaan` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `logo` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `telpon` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `fax` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `website` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id_profil_perusahaan`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `profil_perusahaan` (`id_profil_perusahaan`, `nama_perusahaan`, `logo`, `telpon`, `fax`, `email`, `website`, `alamat`) VALUES (3, 'PT Cipta Nugraha', 'uploads/e1c8f0130083fe9007a81e1ee71e92e6.png', '021021233', NULL, 'cipta@mail.com', 'www.test.com', 'Jl. Cakung Barat');


#
# TABLE STRUCTURE FOR: retur_penjualan
#

DROP TABLE IF EXISTS `retur_penjualan`;

CREATE TABLE `retur_penjualan` (
  `id_retur_penjualan` int(11) NOT NULL AUTO_INCREMENT,
  `no_retur` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `tanggal` date NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `total` double NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_retur_penjualan`),
  UNIQUE KEY `no_retur` (`no_retur`),
  KEY `id_pelanggan` (`id_pelanggan`),
  CONSTRAINT `retur_penjualan_ibfk_1` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `retur_penjualan` (`id_retur_penjualan`, `no_retur`, `tanggal`, `id_pelanggan`, `total`, `status`) VALUES (3, 'RET-01', '2020-10-05', 1, '25000', 0);


#
# TABLE STRUCTURE FOR: retur_supplier
#

DROP TABLE IF EXISTS `retur_supplier`;

CREATE TABLE `retur_supplier` (
  `id_retur_supplier` int(11) NOT NULL AUTO_INCREMENT,
  `no_retur` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `tanggal` date NOT NULL,
  `id_supplier` int(11) NOT NULL,
  `total` double NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_retur_supplier`),
  UNIQUE KEY `no_retur` (`no_retur`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `retur_supplier` (`id_retur_supplier`, `no_retur`, `tanggal`, `id_supplier`, `total`, `status`) VALUES (4, '02', '2020-10-07', 2, '50000', 0);


#
# TABLE STRUCTURE FOR: supplier
#

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `id_supplier` int(11) NOT NULL AUTO_INCREMENT,
  `nama_supplier` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `alamat` text COLLATE utf8mb4_bin NOT NULL,
  `kota` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `kontak` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id_supplier`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `supplier` (`id_supplier`, `nama_supplier`, `alamat`, `kota`, `kontak`) VALUES (1, 'AHMAD', 'Majalengka, Jawa barat', 'MAJALENGKA', '082176412811');
INSERT INTO `supplier` (`id_supplier`, `nama_supplier`, `alamat`, `kota`, `kontak`) VALUES (2, 'Ujang', 'Tasikmalaya, Jawa Barat', 'Tasikmalaya', '08172812912');
INSERT INTO `supplier` (`id_supplier`, `nama_supplier`, `alamat`, `kota`, `kontak`) VALUES (3, 'Beni Jaya', 'Depok, Jabar', 'Depok', '08412817278');
INSERT INTO `supplier` (`id_supplier`, `nama_supplier`, `alamat`, `kota`, `kontak`) VALUES (4, 'Handoko', 'Semarang, Jateng', 'Semarang', '09489573878');


